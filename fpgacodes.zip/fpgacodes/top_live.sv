// ============================================================
// top_live.sv   <-- THIS IS YOUR NEW TOP MODULE
// Replaces top_rom_display.sv for live realtime classification.
//
// Hierarchy:
//   top_live
//     uart_rx          -- receives bytes from Python over USB-UART
//     frame_assembler  -- builds 12-feature vector from 25-byte frames
//     classifier       -- your existing dot-product classifier (unchanged)
//     (7-seg logic)    -- copied from your original top_rom_display
//
// Basys3 USB-UART pin:  B18  (LVCMOS33) -- see basys3_live.xdc
// Baud rate:            115200
// ============================================================
module top_live (
    input  logic        clk,      // 100 MHz onboard oscillator  W5
    input  logic        rx,       // USB-UART RX                 B18

    output logic [2:0]  led,      // LD2..LD0 = class_out        (see XDC)
    output logic [6:0]  seg,      // 7-segment cathodes
    output logic [3:0]  an        // 7-segment anodes (active-low)
);

    parameter NUM_FEATURES = 12;

    // ----------------------------------------------------------------
    // Internal wires
    // ----------------------------------------------------------------
    logic [7:0]          uart_data;
    logic                uart_valid;

    logic signed [15:0]  X [0:NUM_FEATURES-1];
    logic                start;       // one-cycle pulse from assembler

    logic [2:0]          class_out;

    // ----------------------------------------------------------------
    // UART RX  (100 MHz clock, 115200 baud)
    // ----------------------------------------------------------------
    uart_rx #(
        .CLK_FREQ(100_000_000),
        .BAUD    (115200)
    ) u_uart_rx (
        .clk  (clk),
        .rx   (rx),
        .data (uart_data),
        .valid(uart_valid)
    );

    // ----------------------------------------------------------------
    // Frame assembler  (25 bytes -> 12 int16 features + start pulse)
    // ----------------------------------------------------------------
    frame_assembler #(
        .NUM_FEATURES(NUM_FEATURES)
    ) u_frame (
        .clk       (clk),
        .uart_data (uart_data),
        .uart_valid(uart_valid),
        .X         (X),
        .frame_done(start)
    );

    // ----------------------------------------------------------------
    // Classifier  (your existing file -- NOT modified at all)
    // ----------------------------------------------------------------
    classifier #(
        .NUM_CLASSES (6),
        .NUM_FEATURES(NUM_FEATURES)
    ) u_classifier (
        .clk      (clk),
        .start    (start),
        .X        (X),
        .class_out(class_out)
    );

    // ----------------------------------------------------------------
    // LEDs -- show class result
    // ----------------------------------------------------------------
    always_ff @(posedge clk)
        led <= class_out;

    // ----------------------------------------------------------------
    // 7-segment display
    // Shows class on digit 0, "rL" (realtime) indicator on digits 1-2
    // (digit1 = 'r' approximation, digit2 blank)
    // ----------------------------------------------------------------
    logic [15:0]  refresh_counter;
    logic [3:0]   digit0, digit1, digit2;
    logic [3:0]   current_digit;
    logic [1:0]   sel;

    always_ff @(posedge clk)
        refresh_counter <= refresh_counter + 1;

    assign sel = refresh_counter[15:14];

    assign digit0 = class_out;   // class number on rightmost digit
    assign digit1 = 4'd15;       // shows blank (default case in decoder)
    assign digit2 = 4'd15;       // shows blank

    always_comb begin
        case (sel)
            2'b00: begin an = 4'b1110; current_digit = digit0; end
            2'b01: begin an = 4'b1101; current_digit = digit1; end
            2'b10: begin an = 4'b1011; current_digit = digit2; end
            default: begin an = 4'b1111; current_digit = 4'd0;  end
        endcase
    end

    // 7-segment decoder (same as your original)
    always_comb begin
        case (current_digit)
            4'd0:    seg = 7'b1000000;
            4'd1:    seg = 7'b1111001;
            4'd2:    seg = 7'b0100100;
            4'd3:    seg = 7'b0110000;
            4'd4:    seg = 7'b0011001;
            4'd5:    seg = 7'b0010010;
            4'd6:    seg = 7'b0000010;
            4'd7:    seg = 7'b1111000;
            4'd8:    seg = 7'b0000000;
            4'd9:    seg = 7'b0010000;
            default: seg = 7'b1111111;  // blank for digits 1 and 2
        endcase
    end

endmodule