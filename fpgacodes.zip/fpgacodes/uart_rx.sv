// ============================================================
// uart_rx.sv
// Standard 8N1 UART receiver
// CLK_FREQ = 100_000_000 (Basys3 onboard oscillator)
// BAUD     = 115200
// Outputs one byte on {data, valid} per received character.
// valid is HIGH for exactly ONE clock cycle.
// ============================================================
module uart_rx #(
    parameter CLK_FREQ = 100_000_000,
    parameter BAUD     = 115200
)(
    input  logic       clk,
    input  logic       rx,
    output logic [7:0] data,
    output logic       valid
);

    localparam integer CLKS_PER_BIT   = CLK_FREQ / BAUD;      // 868
    localparam integer HALF_BIT       = CLKS_PER_BIT / 2;     // 434

    typedef enum logic [1:0] {
        IDLE  = 2'd0,
        START = 2'd1,
        DATA  = 2'd2,
        STOP  = 2'd3
    } state_t;

    state_t             state       = IDLE;
    logic [9:0]         clk_count   = '0;
    logic [2:0]         bit_index   = '0;
    logic [7:0]         rx_shift    = '0;

    // Double-flop synchroniser to avoid metastability
    logic rx_sync0, rx_sync1;
    always_ff @(posedge clk) begin
        rx_sync0 <= rx;
        rx_sync1 <= rx_sync0;
    end

    always_ff @(posedge clk) begin
        valid <= 1'b0;

        case (state)
            IDLE: begin
                if (rx_sync1 == 1'b0) begin   // falling edge = start bit
                    clk_count <= '0;
                    state     <= START;
                end
            end

            // Wait half a bit period then re-sample to confirm start
            START: begin
                if (clk_count == HALF_BIT - 1) begin
                    if (rx_sync1 == 1'b0) begin
                        clk_count <= '0;
                        bit_index <= '0;
                        state     <= DATA;
                    end else begin
                        state <= IDLE;          // glitch, abort
                    end
                end else begin
                    clk_count <= clk_count + 1;
                end
            end

            // Sample each data bit at the centre of its period
            DATA: begin
                if (clk_count < CLKS_PER_BIT - 1) begin
                    clk_count <= clk_count + 1;
                end else begin
                    clk_count          <= '0;
                    rx_shift[bit_index] <= rx_sync1;
                    if (bit_index == 3'd7) begin
                        bit_index <= '0;
                        state     <= STOP;
                    end else begin
                        bit_index <= bit_index + 1;
                    end
                end
            end

            // Wait one stop bit then emit
            STOP: begin
                if (clk_count < CLKS_PER_BIT - 1) begin
                    clk_count <= clk_count + 1;
                end else begin
                    data      <= rx_shift;
                    valid     <= 1'b1;
                    clk_count <= '0;
                    state     <= IDLE;
                end
            end

            default: state <= IDLE;
        endcase
    end

endmodule