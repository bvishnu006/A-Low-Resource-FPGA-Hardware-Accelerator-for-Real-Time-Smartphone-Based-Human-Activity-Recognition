// ============================================================
// classifier.sv  (sequential argmax -- guaranteed 100 MHz)
//
// Root cause of remaining violation: the argmax for-loop
// across 6 x 32-bit values still synthesises to a long
// carry-chain even when bias is separated out.
//
// Fix: replace the for-loop argmax with a sequential
// one-comparison-per-cycle tournament:
//   ARGMAX state runs 5 times (comparing current best
//   against candidate[k] for k = 1..5), updating the
//   registered 'best' each cycle.
//
// Each ARGMAX cycle: ONE 32-bit signed compare = ~3 ns.
// Total extra latency: 5 cycles = 50 ns -- irrelevant at
// 2.5 Hz input rate.
//
// Full pipeline:
//   IDLE       : latch X[], clear sums
//   MULTIPLY   : W[i][j]*X[j] parallel across 6 classes
//   ACCUM      : sum[i] += product[i], advance j
//                (x12 feature loop = 24 cycles)
//   BIAS       : sum[i] = (sum[i]>>>8) + b[i]
//   ARGMAX x5  : one compare per cycle, update best_idx
//   -> class_out registered after 5th compare
// ============================================================
module classifier #(
    parameter NUM_CLASSES  = 6,
    parameter NUM_FEATURES = 12
)(
    input  logic                clk,
    input  logic                start,
    input  logic signed [15:0]  X [0:NUM_FEATURES-1],
    output logic [2:0]          class_out
);

    // ----------------------------------------------------------------
    // Weight and bias ROMs
    // ----------------------------------------------------------------
    logic signed [15:0] W_flat [0:NUM_CLASSES*NUM_FEATURES-1];
    logic signed [15:0] b      [0:NUM_CLASSES-1];

    initial begin
        $readmemh("weights_mem_fixed.mem", W_flat);
        $readmemh("bias_mem_fixed.mem",    b);
    end

    // ----------------------------------------------------------------
    // Pipeline registers
    // ----------------------------------------------------------------
    logic signed [15:0] X_latch [0:NUM_FEATURES-1];
    logic signed [31:0] product [0:NUM_CLASSES-1];
    logic signed [31:0] sum     [0:NUM_CLASSES-1];
    logic [3:0]         j;          // feature index 0..11

    // Sequential argmax state
    logic [2:0]         best_idx;   // index of current best class
    logic [2:0]         cmp_k;      // candidate index being compared (1..5)

    // ----------------------------------------------------------------
    // FSM
    // ----------------------------------------------------------------
    typedef enum logic [2:0] {
        IDLE     = 3'd0,
        MULTIPLY = 3'd1,
        ACCUM    = 3'd2,
        BIAS     = 3'd3,
        ARGMAX   = 3'd4
    } state_t;

    state_t state = IDLE;

    // ----------------------------------------------------------------
    // Pipeline
    // ----------------------------------------------------------------
    always_ff @(posedge clk) begin
        case (state)

            // --------------------------------------------------
            // IDLE
            // --------------------------------------------------
            IDLE: begin
                if (start) begin
                    for (int i = 0; i < NUM_FEATURES; i++)
                        X_latch[i] <= X[i];
                    for (int i = 0; i < NUM_CLASSES; i++)
                        sum[i] <= 32'sd0;
                    j     <= 4'd0;
                    state <= MULTIPLY;
                end
            end

            // --------------------------------------------------
            // MULTIPLY: 6 parallel 16x16 multiplies
            // One DSP48 per class, critical path ~3-4 ns
            // --------------------------------------------------
            MULTIPLY: begin
                for (int i = 0; i < NUM_CLASSES; i++)
                    product[i] <= $signed(W_flat[i * NUM_FEATURES + j])
                                * $signed(X_latch[j]);
                state <= ACCUM;
            end

            // --------------------------------------------------
            // ACCUM: accumulate, loop or finish
            // --------------------------------------------------
            ACCUM: begin
                for (int i = 0; i < NUM_CLASSES; i++)
                    sum[i] <= sum[i] + product[i];

                if (j == NUM_FEATURES - 1) begin
                    state <= BIAS;
                end else begin
                    j     <= j + 4'd1;
                    state <= MULTIPLY;
                end
            end

            // --------------------------------------------------
            // BIAS: apply Q8.8 scale and add bias
            // Six 32-bit adds in parallel, each independent
            // Critical path: one adder ~3 ns
            // --------------------------------------------------
            BIAS: begin
                for (int i = 0; i < NUM_CLASSES; i++)
                    sum[i] <= (sum[i] >>> 8) + $signed({{16{b[i][15]}}, b[i]});
                // Seed argmax: start with class 0 as best, compare from class 1
                best_idx <= 3'd0;
                cmp_k    <= 3'd1;
                state    <= ARGMAX;
            end

            // --------------------------------------------------
            // ARGMAX: ONE comparison per cycle
            // Cycle 1: compare sum[0] vs sum[1]
            // Cycle 2: compare winner vs sum[2]
            // ...
            // Cycle 5: compare winner vs sum[5] -> done
            //
            // Critical path: ONE 32-bit signed compare ~3 ns
            // --------------------------------------------------
            ARGMAX: begin
                // Update best if current candidate beats it
                if ($signed(sum[cmp_k]) > $signed(sum[best_idx]))
                    best_idx <= cmp_k;

                if (cmp_k == NUM_CLASSES - 1) begin
                    // Last comparison done -- register result
                    // (best_idx may update this cycle so we use
                    //  a one-cycle delayed commit via the next IDLE)
                    class_out <= ($signed(sum[cmp_k]) > $signed(sum[best_idx]))
                                 ? cmp_k : best_idx;
                    state     <= IDLE;
                end else begin
                    cmp_k <= cmp_k + 3'd1;
                end
            end

            default: state <= IDLE;

        endcase
    end

endmodule