// ============================================================
// tb_top_live.sv
// Testbench for top_live.sv
//
// What it does:
//   1. Generates 100 MHz clock
//   2. Sends one complete 25-byte UART frame over rx pin
//      (0xAA start byte + 12 x int16 test feature vector)
//   3. Waits for class_out to settle
//   4. Prints the result to the console
//
// To add in Vivado:
//   Add Sources -> Add Files -> tb_top_live.sv
//   Set Simulation Top: tb_top_live
//   Run Simulation -> Run Behavioral Simulation
// ============================================================
`timescale 1ns / 1ps

module tb_top_live;

    // ----------------------------------------------------------------
    // Clock and reset
    // ----------------------------------------------------------------
    localparam CLK_PERIOD = 10;  // 10 ns = 100 MHz

    logic clk = 0;
    logic rx  = 1;   // idle high (UART idle state)

    always #(CLK_PERIOD/2) clk = ~clk;

    // ----------------------------------------------------------------
    // DUT outputs
    // ----------------------------------------------------------------
    logic [2:0] led;
    logic [6:0] seg;
    logic [3:0] an;

    // ----------------------------------------------------------------
    // DUT instantiation
    // ----------------------------------------------------------------
    top_live dut (
        .clk (clk),
        .rx  (rx),
        .led (led),
        .seg (seg),
        .an  (an)
    );

    // ----------------------------------------------------------------
    // UART transmit task
    // Sends one byte at 115200 baud (8N1)
    // Bit period = 1_000_000_000 / 115200 = 8680 ns
    // ----------------------------------------------------------------
    localparam integer BIT_PERIOD = 8680;  // ns

    task uart_send_byte(input logic [7:0] data);
        integer k;
        begin
            rx = 0;                        // start bit
            #(BIT_PERIOD);
            for (k = 0; k < 8; k++) begin
                rx = data[k];              // LSB first
                #(BIT_PERIOD);
            end
            rx = 1;                        // stop bit
            #(BIT_PERIOD);
        end
    endtask

    // ----------------------------------------------------------------
    // Send a full 25-byte frame task
    // Frame = 0xAA + 12 x int16 little-endian
    // ----------------------------------------------------------------
    task send_frame(input logic signed [15:0] features [0:11]);
        integer f;
        begin
            uart_send_byte(8'hAA);   // start-of-frame marker
            for (f = 0; f < 12; f++) begin
                uart_send_byte(features[f][7:0]);   // low byte first
                uart_send_byte(features[f][15:8]);  // high byte
            end
        end
    endtask

    // ----------------------------------------------------------------
    // Test stimulus
    // ----------------------------------------------------------------
    logic signed [15:0] test_vector [0:11];

    initial begin
        // ---- Let design come out of initial X state ----
        rx = 1;
        repeat(200) @(posedge clk);

        // ----------------------------------------------------------------
        // TEST 1: vector
        // These are example Q8.8 fixed-point values
        // Replace with real values from your Python pipeline if you want
        // ----------------------------------------------------------------
        $display("\n=== TEST 1: Sending test vector (walking-like) ===");
        test_vector[0]  = 16'sh0180;   // mean_x  =  1.5
        test_vector[1]  = 16'sh0040;   // std_x   =  0.25
        test_vector[2]  = 16'shFF80;   // min_x   = -0.5
        test_vector[3]  = 16'sh0280;   // max_x   =  2.5
        test_vector[4]  = 16'sh0200;   // mean_y  =  2.0
        test_vector[5]  = 16'sh0060;   // std_y   =  0.375
        test_vector[6]  = 16'sh0100;   // min_y   =  1.0
        test_vector[7]  = 16'sh0300;   // max_y   =  3.0
        test_vector[8]  = 16'shFE00;   // mean_z  = -2.0
        test_vector[9]  = 16'sh0080;   // std_z   =  0.5
        test_vector[10] = 16'shFD00;   // min_z   = -3.0
        test_vector[11] = 16'shFF00;   // max_z   = -1.0

        send_frame(test_vector);

        // Wait for classifier to finish (26 cycles max after start pulse)
        repeat(100) @(posedge clk);

        $display("class_out = %0d  (LEDs = %03b)", led, led);
        $display("Expected classes: 0=WALKING 1=WALKING_UPSTAIRS 2=WALKING_DOWNSTAIRS 3=SITTING 4=STANDING 5=LAYING");

        // ----------------------------------------------------------------
        // TEST 2: vector (near-zero motion)
        // ----------------------------------------------------------------
        #(BIT_PERIOD * 5);   // small gap between frames
        $display("\n=== TEST 2: Sending test vector (sitting-like) ===");
        test_vector[0]  = 16'sh0010;   // mean_x  ~0
        test_vector[1]  = 16'sh0005;   // std_x   ~0 (very low motion)
        test_vector[2]  = 16'shFFF8;   // min_x   ~0
        test_vector[3]  = 16'sh0018;   // max_x   ~0
        test_vector[4]  = 16'sh0008;   // mean_y  ~0
        test_vector[5]  = 16'sh0003;   // std_y   ~0
        test_vector[6]  = 16'shFFFC;   // min_y   ~0
        test_vector[7]  = 16'sh000C;   // max_y   ~0
        test_vector[8]  = 16'sh03E8;   // mean_z  ~9.8 m/s2 (gravity)
        test_vector[9]  = 16'sh0004;   // std_z   ~0
        test_vector[10] = 16'sh03E0;   // min_z   ~9.7
        test_vector[11] = 16'sh03F0;   // max_z   ~9.9

        send_frame(test_vector);
        repeat(100) @(posedge clk);

        $display("class_out = %0d  (LEDs = %03b)", led, led);
        $display("Expected classes: 0=WALKING 1=WALKING_UPSTAIRS 2=WALKING_DOWNSTAIRS 3=SITTING 4=STANDING 5=LAYING");

        // ----------------------------------------------------------------
        $display("\n=== Simulation complete ===");
        $finish;
    end

    // ----------------------------------------------------------------
    // Timeout watchdog (prevents infinite sim if something hangs)
    // ----------------------------------------------------------------
    initial begin
        #500_000_000;   // 500 ms sim time
        $display("TIMEOUT - simulation did not finish");
        $finish;
    end

endmodule