// ============================================================
// frame_assembler.sv
// Collects frames sent by the Python pipeline.
// Protocol: 0xAA (start-of-frame) followed by 24 data bytes
//           (12 x int16 little-endian, Q8.8 fixed point).
//
// On receipt of the 24th data byte it:
//   - unpacks the 12 signed 16-bit features into X[]
//   - pulses frame_done HIGH for exactly one clock cycle
//
// frame_done is the 'start' signal wired to classifier.sv
// ============================================================
module frame_assembler #(
    parameter NUM_FEATURES = 12   // 12 x 2 bytes = 24 data bytes
)(
    input  logic             clk,
    input  logic [7:0]       uart_data,
    input  logic             uart_valid,
    output logic signed [15:0] X [0:NUM_FEATURES-1],
    output logic             frame_done   // one-cycle pulse
);

    localparam integer FRAME_BYTES = NUM_FEATURES * 2;  // 24

    // Byte buffer stores all 24 bytes, then unpacks atomically
    logic [7:0]  frame_buf [0:FRAME_BYTES-1];
    logic [4:0]  byte_cnt  = '0;
    logic        in_frame  = 1'b0;

    always_ff @(posedge clk) begin
        frame_done <= 1'b0;

        if (uart_valid) begin

            if (uart_data == 8'hAA) begin
                // Start-of-frame: reset and begin collecting
                byte_cnt <= '0;
                in_frame <= 1'b1;

            end else if (in_frame) begin
                // Store incoming byte
                frame_buf[byte_cnt] <= uart_data;

                if (byte_cnt == FRAME_BYTES - 1) begin
                    // All 24 bytes received.
                    // Non-blocking assignments mean frame_buf[23] won't
                    // resolve until end of timestep, so use uart_data
                    // directly for the final byte of the last pair.
                    for (int i = 0; i < NUM_FEATURES - 1; i++) begin
                        X[i] <= $signed({frame_buf[i*2 + 1], frame_buf[i*2]});
                    end
                    // Last feature uses bytes [22] (already in buf) and [23] (uart_data)
                    X[NUM_FEATURES-1] <= $signed({uart_data, frame_buf[FRAME_BYTES-2]});

                    frame_done <= 1'b1;
                    in_frame   <= 1'b0;
                    byte_cnt   <= '0;
                end else begin
                    byte_cnt <= byte_cnt + 1;
                end
            end
            // Bytes arriving outside a frame are silently ignored
        end
    end

endmodule